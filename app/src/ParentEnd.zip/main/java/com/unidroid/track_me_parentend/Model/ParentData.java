package com.unidroid.track_me_parentend.Model;

public class ParentData {
}
